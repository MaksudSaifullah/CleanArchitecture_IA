import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PluginsRoutingModule } from './plugins-routing.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, PluginsRoutingModule],
})
export class PluginsModule {}
